#include "tab2socketclient.h"
#include "ui_tab2socketclient.h"
#define Kor(str)  QString::fromLocal8Bit(str)

Tab2SocketClient::Tab2SocketClient(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Tab2SocketClient)
{
    ui->setupUi(this);
    pSocketClient = new SocketClient(this);
    ui->pPBSendButton->setEnabled(false);
    connect(ui->pPBserverConnect,SIGNAL(clicked(bool)),this,SLOT(slotConnectToServer(bool)));
    connect(pSocketClient,SIGNAL(sigSocketRecv(QString)),this,SLOT(slotSocketRecvUpdate(QString)));
    connect(ui->pPBSendButton,SIGNAL(clicked()),this,SLOT(slotSocketSendData()));
    connect(ui->pPBRecvDataClear,SIGNAL(clicked()),ui->pTErecvData,SLOT(clear()));

}

void Tab2SocketClient::slotConnectToServer(bool check) {
    bool bOk;
    if(check) {
        pSocketClient->slotConnectToServer(bOk);
        if(bOk) {
            ui->pPBserverConnect->setText("서버종료");
            ui->pPBSendButton->setEnabled(true);
        } else {
            ui->pPBserverConnect->setChecked(false);
        }
    } else {
        pSocketClient->slotClosedByServer();
        ui->pPBserverConnect->setText("서버연결");
        ui->pPBSendButton->setEnabled(false);
    }
}
void Tab2SocketClient::slotSocketSendData() {
    QString strRecvId;
    QString strSendData;

    strRecvId = ui->pLERecvId->text();
    strSendData = ui->pLEsendData->text();

    if(strRecvId.isEmpty())
        strSendData = "[ALLMSG]"+strSendData;
    else
        strSendData = "["+strRecvId+"]"+strSendData;
    pSocketClient->slotSocketSendData(strSendData);
    ui->pLEsendData->clear();

}
void Tab2SocketClient::slotSocketSendData(QString strData) {
    if(ui->pPBserverConnect->isChecked()) {
        pSocketClient->slotSocketSendData(strData);
    }
}
void Tab2SocketClient::slotSocketRecvUpdate(QString strRecvData) {

    QTime time = QTime::currentTime();
    QString strTime = time.toString();

    strTime = strTime + " " + strRecvData;
    ui->pTErecvData->append(strTime);
    ui->pTErecvData->moveCursor(QTextCursor::End);

    if((strRecvData.indexOf("New connected") != -1) || \
            (strRecvData.indexOf("Already logged") != -1) || \
            (strRecvData.indexOf("Authentication Error") != -1))
        return;
    //수신포멧 : [KSH_QT]LED@1@ON
    //       @KSH_QT@LED@1@ON
    strRecvData.replace("[","@");
    strRecvData.replace("]","@");
    QStringList qlist = strRecvData.split("@"); //qlist[1] : 송신자ID

//    for(int i=0;i<qlist.size();i++)
//        qDebug() << " i : " << i << " ," + qlist[i];

//    foreach(QString str, qlist)
//        qDebug() << str;
    if(strRecvData.indexOf("LED") != -1) {
        int iLedNo = qlist[3].toInt();

        if(qlist[4] == "ON") {
            iNewLedNo |= (0x01 << (iLedNo-1));
        } else {
            iNewLedNo &= ~(0x01 << (iLedNo-1));
        }
//        qDebug() << "iNewLedNo : " << iNewLedNo;
        emit sigLedWrite(iNewLedNo);
    }else if(((strRecvData.indexOf("LAMP") != -1) || (strRecvData.indexOf("PLUG") != -1)) || (strRecvData.indexOf("GAS") != -1)) {
//        qDebug() << "TEST " << strRecvData;
        emit sigTab3RecvData(strRecvData);
    }else if(strRecvData.indexOf("SENSOR") != -1) {
    //        qDebug() << "TEST " << strRecvData;
        emit sigTab4RecvData(strRecvData);
    }

}
Tab2SocketClient::~Tab2SocketClient()
{
    delete ui;
}
