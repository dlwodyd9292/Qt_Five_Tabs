#include "tab3controlpannel.h"
#include "ui_tab3controlpannel.h"

Tab3ControlPannel::Tab3ControlPannel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Tab3ControlPannel)
{
    ui->setupUi(this);
    connect(ui->pPBLamp,SIGNAL(clicked(bool)),this,SLOT(slotLampOnOff(bool)));
    connect(ui->pPBPlug,SIGNAL(clicked(bool)),this,SLOT(slotPlugOnOff(bool)));
}
void Tab3ControlPannel::slotLampOnOff(bool bCheck) {
    if(bCheck) {
        emit sigSocketSendData("[KSH_LIN]LAMPON");
        ui->pPBLamp->setChecked(false);
    }
    else {
        emit sigSocketSendData("[KSH_LIN]LAMPOFF");
        ui->pPBLamp->setChecked(true);
    }
}
void Tab3ControlPannel::slotPlugOnOff(bool bCheck){
    if(bCheck) {
        emit sigSocketSendData("[HM_CON]GASON");
         ui->pPBPlug->setChecked(false);
    }
    else {
        emit sigSocketSendData("[HM_CON]GASOFF");
        ui->pPBPlug->setChecked(true);
    }
}
void Tab3ControlPannel::slotTab3RecvData(QString recvData) {
//     qDebug() << "TEST1 " << recvData;
    QStringList qlist = recvData.split("@");    //@KSH_QT@LAMPON
    if(qlist[2] =="LAMPON")
         ui->pPBLamp->setChecked(true);
    else if(qlist[2] =="LAMPOFF")
         ui->pPBLamp->setChecked(false);
    else if(qlist[2] =="GASON")
         ui->pPBPlug->setChecked(true);
    else if(qlist[2] =="GASOFF")
         ui->pPBPlug->setChecked(false);
}
Tab3ControlPannel::~Tab3ControlPannel()
{
    delete ui;
}
