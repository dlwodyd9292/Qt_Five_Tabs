#include "tab4chartplot.h"
#include "ui_tab4chartplot.h"

Tab4ChartPlot::Tab4ChartPlot(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Tab4ChartPlot)
{
    ui->setupUi(this);
    series = new QLineSeries(this);
    series->setName("illumination chart");

    QChart *chart = new QChart();
//    chart->legend()->hide();
    chart->addSeries(series);
    chart->createDefaultAxes();
//    chart->setTitle("illumination chart");
    chart->axes(Qt::Vertical).first()->setRange(0,100);
 //   chart->axes(Qt::Horizontal).first()->setRange(0,50);

    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    ui->verticalLayout->layout()->addWidget(chartView);

    QDateTimeAxis *axisX = new QDateTimeAxis;
//    axisX->setFormat("dd-MM-yyyy h:mm");
    axisX->setFormat("h:mm");

    QDate date = QDate::currentDate();
    QTime time = QTime::currentTime();
    QDateTime latestDate;
    QDateTime firstDate;
    QTime tempTime;

    firstDate.setDate(date);
    firstDate.setTime(time);
    if(time.hour() >= 23)
        tempTime.setHMS(23,59,59);
    else
        tempTime = time.addSecs(60*10*1);

    latestDate.setDate(date);
    latestDate.setTime(tempTime);

    axisX->setRange(firstDate,latestDate);
    chartView->chart()->setAxisX(axisX, series);;

    connect(ui->pPBAddButton,SIGNAL(clicked()),this, SLOT(slotChartPlotAdd()));
    connect(ui->pPBClearButton,SIGNAL(clicked()),this, SLOT(slotChartPlotClear()));


    sqlDb = QSqlDatabase::addDatabase("QSQLITE");
    sqlDb.setDatabaseName("temp.db");
    if (!QSqlDatabase::contains("my_sql_connection")) {
        if(sqlDb.open()){
            qDebug() << "success DB connection\n";
        }
        else{
//            qDebug() << "fail DB connection\n";
        }
    }

    QString query = "CREATE TABLE temp_db ("
            "id integer primary key,"
            "date DATETIME,"
            "illu VARCHAR(10),"
            "temp VARCHAR(10),"
            "humi VARCHAR(10))" ;
    QSqlQuery qry;
    if(!qry.exec(query))
    {
//         qDebug() << "error creating table\n";
    } else
         qDebug() << "create table\n";

}
void Tab4ChartPlot::slotChartPlotAdd() {
    QDateTime dateTime = QDateTime::currentDateTime();
    QDate date = QDate::currentDate();
    QTime time = QTime::currentTime();
    QString strTime = time.toString();
    QDateTime xValue;
    xValue.setDate(date);
    xValue.setTime(time);

//    int x = ui->pLExPosition->text().toInt();
    int y = ui->pLEyPosition->text().toInt();

    series->append(xValue.toMSecsSinceEpoch(), y);

    ui->pLExPosition->clear();
    ui->pLEyPosition->clear();

    QSqlQuery query;
    QString temp(QString::number(y));

    if(query.exec("insert into temp_db(date, temp) values('" + dateTime.toString("yy/MM/dd hh:mm:ss") +"' , '" + temp + "')")){
//         qDebug() << query.lastQuery();
     }
     else {
 //        qDebug() << query.lastError().text();
     }

}
void Tab4ChartPlot::slotTab4RecvData(QString recvData) {

    QString illu,temp,humi;
    QDateTime dateTime = QDateTime::currentDateTime();
    QDate date = QDate::currentDate();
    QTime time = QTime::currentTime();
    QString strTime = time.toString();
    QDateTime xValue;
    xValue.setDate(date);
    xValue.setTime(time);

    qDebug() << "TEST1 " << recvData;
    QStringList qlist = recvData.split("@");    //@KSH_QT@LAMPON
    if(qlist[2] =="SENSOR") {
        illu = qlist[3];
        temp = qlist[4];
        humi = qlist[5];
    }
//    int x = ui->pLExPosition->text().toInt();
//    int y = ui->pLEyPosition->text().toInt();

    series->append(xValue.toMSecsSinceEpoch(), illu.toUInt());
//    qDebug() << "TEST1 " <<illu + " " <<temp + " " <<humi  ;
    ui->pLExPosition->clear();
    ui->pLEyPosition->clear();

    QSqlQuery query;
//    QString temp(QString::number(y));

      if(query.exec("insert into temp_db(date, illu, temp, humi) values('" + dateTime.toString("yy/MM/dd hh:mm:ss") +"' , '" + illu + "' , '" + temp + "', '" + humi + "')")){
//         qDebug() << query.lastQuery();
     }
     else {
//         qDebug() << query.lastError().text();
     }

}
void Tab4ChartPlot::slotChartPlotClear() {
    series->clear();
}
Tab4ChartPlot::~Tab4ChartPlot()
{
    delete ui;
}
